智能聊天助手 - 开箱即用版

✅ 运行要求：
- 已安装 Java 11 或更高版本（JRE 即可）
- 支持 Windows / macOS / Linux

🚀 使用方法：
- Windows：双击 run.bat
- macOS / Linux：双击 run.sh（或终端运行 ./run.sh）

⚙️ 配置说明：
- 首次运行会加载 config.properties
- 点击界面上的“⚙️ 设置”按钮，可图形化修改 API 地址、Key 和模型

💡 获取 DashScope API Key：
https://dashscope.console.aliyun.com/apiKey

作者：EterUltimate