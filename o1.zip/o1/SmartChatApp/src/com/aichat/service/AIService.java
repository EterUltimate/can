// src/com/aichat/service/AIService.java
package com.aichat.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class AIService {
    private static final String MODELS_URL = "https://dashscope.aliyuncs.com/api/v1/models";
    private static final String CHAT_URL = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation";

    private final String apiKey;
    private final HttpClient client;
    private final ObjectMapper objectMapper;

    public AIService(String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("API Key 不能为空");
        }
        this.apiKey = apiKey.trim();
        this.client = HttpClient.newBuilder()
                .connectTimeout(java.time.Duration.ofSeconds(10))
                .build();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * 获取当前账号可用的模型列表
     */
    public List<String> fetchAvailableModels() throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(MODELS_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("获取模型列表失败 (" + response.statusCode() + "): " + response.body());
        }

        // 🔥 修复：原错误 "read擎" → 正确为 "readTree"
        JsonNode root = objectMapper.readTree(response.body());
        JsonNode modelsArray = root.path("models");

        List<String> modelNames = new ArrayList<>();
        if (modelsArray.isArray()) {
            for (JsonNode model : modelsArray) {
                String name = model.path("name").asText();
                if (!name.isEmpty()) {
                    modelNames.add(name);
                }
            }
        }
        return modelNames;
    }

    /**
     * 调用大模型生成回复
     */
    public String generateText(String model, String userMessage) throws Exception {
        // 转义双引号防止 JSON 注入
        String escapedMessage = userMessage.replace("\"", "\\\"");

        String jsonPayload = """
        {
          "model": "%s",
          "input": {
            "messages": [
              {"role": "user", "content": "%s"}
            ]
          },
          "parameters": {}
        }
        """.formatted(model, escapedMessage);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(CHAT_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("AI 调用失败 (" + response.statusCode() + "): " + response.body());
        }

        JsonNode root = objectMapper.readTree(response.body());
        return root.path("output").path("text").asText();
    }
}