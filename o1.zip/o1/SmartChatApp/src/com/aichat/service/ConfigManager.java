// src/com/aichat/service/ConfigManager.java
package com.aichat.service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class ConfigManager {
    private Properties props;
    private final File configFile;

    public ConfigManager() {
        this.configFile = getConfigFile();
        this.props = new Properties();
        load();
    }

    private File getConfigFile() {
        String home = System.getProperty("user.home");
        String os = System.getProperty("os.name").toLowerCase();
        Path configDir;

        if (os.contains("win")) {
            configDir = Paths.get(home, ".smartchatapp");
        } else if (os.contains("mac")) {
            configDir = Paths.get(home, "Library", "Application Support", "SmartChatApp");
        } else {
            configDir = Paths.get(home, ".config", "smartchatapp");
        }

        try {
            Files.createDirectories(configDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return configDir.resolve("config.properties").toFile();
    }

    private void load() {
        if (configFile.exists()) {
            try (FileInputStream fis = new FileInputStream(configFile)) {
                props.load(fis);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void save() {
        try (FileOutputStream fos = new FileOutputStream(configFile)) {
            props.store(fos, "SmartChatApp Configuration");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Getters & Setters
    public String getApiKey() { return props.getProperty("api.key", ""); }
    public void setApiKey(String key) { props.setProperty("api.key", key); }

    public String getApiUrl() { return props.getProperty("api.url", "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"); }
    public void setApiUrl(String url) { props.setProperty("api.url", url); }

    public String getModel() { return props.getProperty("api.model", "qwen-max"); }
    public void setModel(String model) { props.setProperty("api.model", model); }
}