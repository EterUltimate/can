// src/com/aichat/view/SettingsDialog.java
package com.aichat.view;

import com.aichat.service.AIService;
import com.aichat.service.ConfigManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class SettingsDialog extends JDialog {
    private final ConfigManager configManager;
    private JPasswordField apiKeyField;
    private JTextField apiUrlField;
    private JComboBox<String> modelComboBox;
    private JButton refreshModelsButton;

    public SettingsDialog(Frame owner, ConfigManager configManager) {
        super(owner, "⚙️ 设置", true);
        this.configManager = configManager;
        initComponents();
        loadConfig();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);

        // API Key
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("DashScope API Key:"), gbc);
        apiKeyField = new JPasswordField(25);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(apiKeyField, gbc);

        // API URL
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("API 地址:"), gbc);
        apiUrlField = new JTextField(25);
        gbc.gridx = 1;
        panel.add(apiUrlField, gbc);

        // 模型选择
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("模型:"), gbc);

        JPanel modelPanel = new JPanel(new BorderLayout());
        modelComboBox = new JComboBox<>();
        modelComboBox.setEditable(false);
        refreshModelsButton = new JButton("🔄 刷新");
        refreshModelsButton.addActionListener(e -> fetchAndLoadModels());
        modelPanel.add(modelComboBox, BorderLayout.CENTER);
        modelPanel.add(refreshModelsButton, BorderLayout.EAST);
        gbc.gridx = 1;
        panel.add(modelPanel, gbc);

        // 按钮
        JPanel buttonPanel = new JPanel();
        JButton saveBtn = new JButton("保存");
        JButton cancelBtn = new JButton("取消");
        saveBtn.addActionListener(this::onSave);
        cancelBtn.addActionListener(e -> dispose());
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setResizable(false);
        setLocationRelativeTo(getOwner());
    }

    private void loadConfig() {
        apiKeyField.setText(configManager.getApiKey());
        apiUrlField.setText(configManager.getApiUrl());
        SwingUtilities.invokeLater(this::fetchAndLoadModels);
    }

    private void fetchAndLoadModels() {
        char[] pw = apiKeyField.getPassword();
        String key = new String(pw).trim();
        if (key.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "请先填写 API Key，才能加载模型列表。",
                    "提示", JOptionPane.WARNING_MESSAGE);
            setDefaultModels();
            return;
        }

        modelComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"加载中..."}));
        modelComboBox.setEnabled(false);
        refreshModelsButton.setEnabled(false);

        CompletableFuture.supplyAsync(() -> {
            try {
                AIService service = new AIService(key); // 🔥 传 String，不是 ConfigManager
                return service.fetchAvailableModels(); // 返回 List<String>
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }).thenAcceptAsync(modelList -> {
            SwingUtilities.invokeLater(() -> {
                modelComboBox.setEnabled(true);
                refreshModelsButton.setEnabled(true);

                if (modelList != null && !modelList.isEmpty()) {
                    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
                    for (String m : modelList) model.addElement(m); // ✅ for-each 正常工作
                    modelComboBox.setModel(model);

                    String current = configManager.getModel();
                    if (current != null) modelComboBox.setSelectedItem(current);
                } else {
                    setDefaultModels();
                    JOptionPane.showMessageDialog(this,
                            "无法加载模型列表，请检查网络或 API Key 是否有效。",
                            "错误", JOptionPane.ERROR_MESSAGE);
                }
            });
        });
    }

    private void setDefaultModels() {
        String[] defaults = {"qwen-max", "qwen-plus", "qwen-turbo"};
        modelComboBox.setModel(new DefaultComboBoxModel<>(defaults));
        String current = configManager.getModel();
        if (current != null) modelComboBox.setSelectedItem(current);
    }

    private void onSave(ActionEvent e) {
        String apiKey = new String(apiKeyField.getPassword()).trim();
        String apiUrl = apiUrlField.getText().trim();
        String model = (String) modelComboBox.getSelectedItem();

        if (apiKey.isEmpty()) {
            JOptionPane.showMessageDialog(this, "API Key 不能为空！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        configManager.setApiKey(apiKey);
        configManager.setApiUrl(apiUrl);
        configManager.setModel(model);
        configManager.save();

        JOptionPane.showMessageDialog(this, "设置已保存！", "成功", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }
}