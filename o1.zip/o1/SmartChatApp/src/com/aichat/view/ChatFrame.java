// src/com/aichat/view/ChatFrame.java
package com.aichat.view;

import com.aichat.controller.ChatController;
import com.aichat.service.ConfigManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class ChatFrame extends JFrame {
    // ✅ 成员变量：整个类都可以访问
    private final ConfigManager configManager = new ConfigManager();
    private JTextArea chatArea;
    private JTextField inputField; // ← 关键：在这里声明！

    public ChatFrame() {
        setTitle("SmartChatApp");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // 菜单栏
        JMenuBar menuBar = new JMenuBar();
        JMenu settingsMenu = new JMenu("设置");
        settingsMenu.setMnemonic(KeyEvent.VK_S);
        JMenuItem settingsItem = new JMenuItem("API 设置", KeyEvent.VK_A);
        settingsItem.addActionListener(e -> new SettingsDialog(this, configManager).setVisible(true));
        settingsMenu.add(settingsItem);
        menuBar.add(settingsMenu);
        setJMenuBar(menuBar);

        // 聊天区域
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        // 输入区域
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField(); // ← 这里只是赋值，不是声明！
        JButton sendBtn = new JButton("发送");
        sendBtn.addActionListener(this::onSend);
        inputField.addActionListener(this::onSend); // 回车发送
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendBtn, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);
    }

    private void onSend(ActionEvent e) {
        String message = inputField.getText().trim(); // ← 现在可以正常访问！
        if (message.isEmpty()) return;

        chatArea.append("👤 You: " + message + "\n");
        inputField.setText(""); // ← 也可以清空
        chatArea.setCaretPosition(chatArea.getDocument().getLength());

        // 异步调用 AI
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() throws Exception {
                ChatController controller = new ChatController(configManager);
                return controller.sendMessage(message);
            }

            @Override
            protected void done() {
                try {
                    String reply = get();
                    chatArea.append("🤖 AI: " + reply + "\n\n");
                    chatArea.setCaretPosition(chatArea.getDocument().getLength());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ChatFrame.this,
                            "AI 调用失败:\n" + ex.getMessage(),
                            "错误", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                    chatArea.append("❌ AI: 出错了，请检查 API Key 或网络。\n\n");
                }
            }
        };
        worker.execute();
    }
}