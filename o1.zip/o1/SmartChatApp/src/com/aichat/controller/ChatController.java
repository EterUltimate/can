// src/com/aichat/controller/ChatController.java
package com.aichat.controller;

import com.aichat.service.AIService;
import com.aichat.service.ConfigManager;

public class ChatController {
    private final AIService aiService;
    private final ConfigManager configManager;

    public ChatController(ConfigManager configManager) {
        this.configManager = configManager;
        String apiKey = configManager.getApiKey();
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalStateException("请先在设置中配置 API Key");
        }
        this.aiService = new AIService(apiKey);
    }

    /**
     * 发送消息并获取 AI 回复
     */
    public String sendMessage(String userMessage) throws Exception {
        // 从配置中读取当前选中的模型（替代 "selectedModel" 变量）
        String selectedModel = configManager.getModel();
        if (selectedModel == null || selectedModel.trim().isEmpty()) {
            selectedModel = "qwen-max"; // 默认模型
        }
        return aiService.generateText(selectedModel, userMessage);
    }
}