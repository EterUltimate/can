// src/com/aichat/Main.java
package com.aichat;

import com.aichat.view.ChatFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new ChatFrame().setVisible(true);
        });
    }
}