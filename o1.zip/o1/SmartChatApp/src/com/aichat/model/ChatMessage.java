package com.aichat.model;

public class ChatMessage {
    private int id;
    private String userMessage;
    private String aiResponse;
    private long timestamp;

    public ChatMessage(String user, String ai) {
        this.userMessage = user;
        this.aiResponse = ai;
        this.timestamp = System.currentTimeMillis();
    }

    // Getters & Setters (手写)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUserMessage() { return userMessage; }
    public String getAiResponse() { return aiResponse; }
    public long getTimestamp() { return timestamp; }
}