// src/com/aichat/service/ConfigManager.java
package com.aichat.service;

import java.io.*;
import java.util.Properties;

public class ConfigManager {
    private static final String CONFIG_FILE = "config.properties";
    private Properties props = new Properties();

    public ConfigManager() throws IOException {
        load();
    }

    public void load() throws IOException {
        // 优先从工作目录加载（可写）
        File file = new File(CONFIG_FILE);
        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                props.load(fis);
                return;
            }
        }

        // 其次从 resources 加载（只读模板）
        try (InputStream in = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (in != null) {
                props.load(in);
                return;
            }
        }

        // 默认值
        setDefaults();
    }

    private void setDefaults() {
        props.setProperty("api.url", "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation");
        props.setProperty("api.key", "");
        props.setProperty("api.model", "qwen-max");
        props.setProperty("api.provider", "dashscope");
    }

    public String getProperty(String key) {
        return props.getProperty(key, "");
    }

    public void setProperty(String key, String value) {
        props.setProperty(key, value);
    }

    public void saveToFile() throws IOException {
        try (FileOutputStream out = new FileOutputStream(CONFIG_FILE)) {
            props.store(out, "AI Chat Configuration - Saved by GUI");
        }
    }
}