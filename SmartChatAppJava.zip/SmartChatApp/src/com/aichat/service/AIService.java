// src/com/aichat/service/AIService.java
package com.aichat.service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class AIService {
    private final ConfigManager config;

    public AIService(ConfigManager config) {
        this.config = config;
    }

    public String callAI(String userMessage) {
        try {
            String apiUrl = config.getProperty("api.url");
            String apiKey = config.getProperty("api.key");
            String model = config.getProperty("api.model");
            String provider = config.getProperty("api.provider").toLowerCase();

            String jsonBody = buildRequestBody(userMessage, model, provider);
            HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(60))
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody));

            if (!apiKey.isEmpty() && !"ollama".equalsIgnoreCase(apiKey)) {
                requestBuilder.setHeader("Authorization", "Bearer " + apiKey);
            }

            HttpRequest request = requestBuilder.build();
            HttpResponse<String> response = HttpClient.newHttpClient()
                    .send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                return extractResponseText(response.body(), provider);
            } else {
                return "API 错误 [" + response.statusCode() + "]: " + response.body();
            }
        } catch (Exception e) {
            return "请求异常: " + e.getMessage();
        }
    }

    private String buildRequestBody(String userMessage, String model, String provider) {
        String escapedMsg = escapeJson(userMessage);
        switch (provider) {
            case "openai":
                return String.format("{\"model\":\"%s\",\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}]}", model, escapedMsg);
            case "dashscope":
            default:
                return String.format("{\"model\":\"%s\",\"input\":{\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}]}}", model, escapedMsg);
        }
    }

    private String extractResponseText(String responseBody, String provider) {
        switch (provider) {
            case "openai":
                int startIdx = responseBody.indexOf("\"content\":\"");
                if (startIdx == -1) return "无法解析 OpenAI 响应";
                startIdx += 11;
                int endIdx = responseBody.indexOf("\"", startIdx);
                return unescapeJson(responseBody.substring(startIdx, endIdx));

            case "dashscope":
            default:
                int textStart = responseBody.indexOf("\"text\":\"");
                if (textStart == -1) return "无法解析 DashScope 响应";
                textStart += 8;
                int textEnd = responseBody.indexOf("\"", textStart);
                return unescapeJson(responseBody.substring(textStart, textEnd));
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static String unescapeJson(String s) {
        return s.replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r");
    }
}