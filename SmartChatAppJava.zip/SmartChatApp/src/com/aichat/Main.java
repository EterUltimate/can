// src/com/aichat/Main.java
package com.aichat;

import com.aichat.controller.ChatController;
import com.aichat.service.AIService;
import com.aichat.service.ConfigManager;
import com.aichat.storage.ChatStorage;
import com.aichat.view.ChatFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {
            // 初始化配置
            ConfigManager config = new ConfigManager();
            ChatStorage storage = new ChatStorage();
            AIService aiService = new AIService(config);
            ChatController controller = new ChatController(storage, aiService);

            SwingUtilities.invokeLater(() -> {
                try {
                    new ChatFrame(controller, config).setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "启动失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "初始化失败: " + e.getMessage(), "致命错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}