// src/com/aichat/controller/ChatController.java
package com.aichat.controller;

import com.aichat.service.AIService;
import com.aichat.storage.ChatStorage;
import com.aichat.model.ChatMessage;

import java.util.List;

public class ChatController {
    private final ChatStorage storage;
    private final AIService aiService;

    // 接受依赖注入
    public ChatController(ChatStorage storage, AIService aiService) {
        this.storage = storage;
        this.aiService = aiService;
    }

    public String askAI(String question) {
        return aiService.callAI(question);
    }

    public void saveMessage(String user, String ai) throws Exception {
        storage.save(new ChatMessage(user, ai));
    }

    public List<ChatMessage> getHistory() throws Exception {
        return storage.findAll();
    }

    public void deleteMessage(int id) throws Exception {
        storage.deleteById(id);
    }

    public void clearHistory() throws Exception {
        storage.clearAll();
    }
}