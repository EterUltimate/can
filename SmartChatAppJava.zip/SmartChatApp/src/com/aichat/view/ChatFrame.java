// src/com/aichat/view/ChatFrame.java
package com.aichat.view;

import com.aichat.controller.ChatController;
import com.aichat.service.ConfigManager;
import com.aichat.model.ChatMessage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public class ChatFrame extends JFrame {
    private final ChatController controller;
    private final ConfigManager configManager;

    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private JButton clearButton;
    private JButton settingsButton;

    public ChatFrame(ChatController controller, ConfigManager configManager) throws Exception {
        this.controller = controller;
        this.configManager = configManager;
        initComponents();
        loadHistory();
    }

    private void initComponents() {
        setTitle("智能聊天助手");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 聊天显示区域
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);

        // 顶部工具栏
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        settingsButton = new JButton("⚙️ 设置");
        settingsButton.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> {
                new SettingsDialog(this, configManager).setVisible(true);
            });
        });
        topPanel.add(settingsButton);
        add(topPanel, BorderLayout.NORTH);

        // 底部输入区域
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        inputField.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sendButton = new JButton("发送");
        clearButton = new JButton("清空");

        sendButton.addActionListener(e -> sendMessage());
        clearButton.addActionListener(e -> clearChat());

        buttonPanel.add(clearButton);
        buttonPanel.add(sendButton);

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(buttonPanel, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        // 回车发送
        inputField.addActionListener(e -> sendMessage());

        // 窗口关闭时保存（可选）
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    private void sendMessage() {
        String userText = inputField.getText().trim();
        if (userText.isEmpty()) return;

        // 显示用户消息
        appendMessage("👤 你", userText);

        // 清空输入框并禁用（防止重复点击）
        inputField.setText("");
        inputField.setEnabled(false);
        sendButton.setEnabled(false);

        // 异步调用 AI
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() {
                return controller.askAI(userText);
            }

            @Override
            protected void done() {
                try {
                    String aiResponse = get();
                    appendMessage("🤖 AI", aiResponse);

                    // 保存到历史（可选）
                    try {
                        controller.saveMessage(userText, aiResponse);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(ChatFrame.this,
                                "保存消息失败: " + ex.getMessage(),
                                "警告", JOptionPane.WARNING_MESSAGE);
                    }
                } catch (Exception ex) {
                    String errorMsg = "AI 请求失败: " + ex.getMessage();
                    appendMessage("❌ 系统", errorMsg);
                } finally {
                    inputField.setEnabled(true);
                    sendButton.setEnabled(true);
                    inputField.requestFocusInWindow();
                }
            }
        };
        worker.execute();
    }

    private void appendMessage(String sender, String message) {
        chatArea.append(sender + ":\n" + message + "\n\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    private void loadHistory() {
        SwingWorker<List<ChatMessage>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<ChatMessage> doInBackground() throws Exception {
                return controller.getHistory();
            }

            @Override
            protected void done() {
                try {
                    List<ChatMessage> history = get();
                    for (ChatMessage msg : history) {
                        appendMessage("👤 你", msg.getUserMessage());
                        appendMessage("🤖 AI", msg.getAiResponse());
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ChatFrame.this,
                            "加载历史记录失败: " + ex.getMessage(),
                            "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        worker.execute();
    }

    private void clearChat() {
        int result = JOptionPane.showConfirmDialog(
                this,
                "确定要清空所有聊天记录吗？",
                "确认清空",
                JOptionPane.YES_NO_OPTION
        );
        if (result == JOptionPane.YES_OPTION) {
            chatArea.setText("");
            try {
                controller.clearHistory();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "清空失败: " + ex.getMessage(),
                        "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}