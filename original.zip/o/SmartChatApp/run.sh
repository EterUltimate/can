#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if ! command -v java &> /dev/null; then
    echo "❌ 未检测到 Java！请安装 Java 11 或更高版本。"
    echo "官网: https://www.oracle.com/java/technologies/downloads/"
    read -p "按回车键退出..."
    exit 1
fi

java -jar SmartChatApp.jar