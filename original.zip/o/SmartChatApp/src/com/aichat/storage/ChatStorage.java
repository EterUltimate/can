package com.aichat.storage;

import com.aichat.model.ChatMessage;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ChatStorage {
    private static final Path HISTORY_FILE = Paths.get("chat_history.json");
    private final AtomicInteger nextId = new AtomicInteger(1);

    public ChatStorage() {
        loadAll().forEach(msg -> {
            if (msg.getId() >= nextId.get()) {
                nextId.set(msg.getId() + 1);
            }
        });
    }

    // 保存单条消息
    public synchronized void save(ChatMessage msg) throws IOException {
        msg.setId(nextId.getAndIncrement());
        List<ChatMessage> all = loadAll();
        all.add(msg);
        writeToFile(all);
    }

    // 查询所有
    public synchronized List<ChatMessage> findAll() throws IOException {
        return new ArrayList<>(loadAll());
    }

    // 删除单条
    public synchronized void deleteById(int id) throws IOException {
        List<ChatMessage> all = loadAll();
        all.removeIf(msg -> msg.getId() == id);
        writeToFile(all);
    }

    // 清空
    public synchronized void clearAll() throws IOException {
        Files.write(HISTORY_FILE, Collections.emptyList(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        nextId.set(1);
    }

    // --- 私有工具方法 ---
    private List<ChatMessage> loadAll() {
        if (!Files.exists(HISTORY_FILE)) {
            return new ArrayList<>();
        }
        try {
            String content = Files.readString(HISTORY_FILE);
            if (content.trim().isEmpty() || content.equals("[]")) {
                return new ArrayList<>();
            }
            return parseJsonArray(content);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>(); // 损坏时返回空
        }
    }

    private void writeToFile(List<ChatMessage> messages) throws IOException {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < messages.size(); i++) {
            ChatMessage msg = messages.get(i);
            sb.append(String.format(
                    "  {\"id\":%d,\"user\":\"%s\",\"ai\":\"%s\",\"ts\":%d}%s\n",
                    msg.getId(),
                    escapeJson(msg.getUserMessage()),
                    escapeJson(msg.getAiResponse()),
                    msg.getTimestamp(),
                    i == messages.size() - 1 ? "" : ","
            ));
        }
        sb.append("]");
        Files.createDirectories(HISTORY_FILE.getParent());
        Files.writeString(HISTORY_FILE, sb.toString(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    // 简易 JSON 转义
    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    // 极简 JSON 数组解析（仅支持本项目格式）
    private List<ChatMessage> parseJsonArray(String json) {
        List<ChatMessage> list = new ArrayList<>();
        // 移除首尾 [ ]
        String content = json.trim();
        if (content.startsWith("[") && content.endsWith("]")) {
            content = content.substring(1, content.length() - 1).trim();
        }
        if (content.isEmpty()) return list;

        // 按对象分割（简单按 }{ 分割，实际应更健壮，但够用）
        String[] objects = content.split("\\},\\s*\\{");
        for (String obj : objects) {
            obj = obj.trim();
            if (obj.startsWith("{")) obj = obj.substring(1);
            if (obj.endsWith("}")) obj = obj.substring(0, obj.length() - 1);

            try {
                int id = parseIntField(obj, "id");
                String user = parseStringField(obj, "user");
                String ai = parseStringField(obj, "ai");
                long ts = parseLongField(obj, "ts");

                ChatMessage msg = new ChatMessage(user, ai);
                msg.setId(id);
                // ts 已在构造函数设为当前时间，这里覆盖
                java.lang.reflect.Field f = ChatMessage.class.getDeclaredField("timestamp");
                f.setAccessible(true);
                f.setLong(msg, ts);
                list.add(msg);
            } catch (Exception e) {
                // 忽略损坏条目
            }
        }
        return list;
    }

    // 辅助解析
    private int parseIntField(String obj, String key) {
        int start = obj.indexOf("\"" + key + "\":") + key.length() + 3;
        int end = obj.indexOf(",", start);
        if (end == -1) end = obj.length();
        return Integer.parseInt(obj.substring(start, end).trim());
    }

    private long parseLongField(String obj, String key) {
        int start = obj.indexOf("\"" + key + "\":") + key.length() + 3;
        int end = obj.indexOf(",", start);
        if (end == -1) end = obj.length();
        return Long.parseLong(obj.substring(start, end).trim());
    }

    private String parseStringField(String obj, String key) {
        int start = obj.indexOf("\"" + key + "\":\"") + key.length() + 3;
        int end = obj.indexOf("\"", start);
        String value = obj.substring(start, end);
        // 反转义
        return value.replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r");
    }
}