// src/com/aichat/view/SettingsDialog.java
package com.aichat.view;

import com.aichat.service.ConfigManager;

import javax.swing.*;
import java.awt.*;

public class SettingsDialog extends JDialog {
    private final ConfigManager config;
    private JTextField urlField;
    private JPasswordField keyField;
    private JComboBox<String> modelComboBox;
    private JComboBox<String> providerComboBox;

    public SettingsDialog(Frame owner, ConfigManager config) {
        super(owner, "AI 设置", true);
        this.config = config;
        initUI();
        loadConfig();
        setSize(520, 260);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // API URL
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("API URL:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        urlField = new JTextField(30);
        panel.add(urlField, gbc);

        // API Key
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("API Key:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        keyField = new JPasswordField(30);
        panel.add(keyField, gbc);

        // Model
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("模型:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        String[] models = {"qwen-max", "qwen-plus", "gpt-4o", "gpt-4o-mini", "llama3.2", "mistral", "claude-3-haiku"};
        modelComboBox = new JComboBox<>(models);
        modelComboBox.setEditable(true);
        panel.add(modelComboBox, gbc);

        // Provider
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        panel.add(new JLabel("Provider:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        providerComboBox = new JComboBox<>(new String[]{"dashscope", "openai"});
        panel.add(providerComboBox, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveBtn = new JButton("保存");
        JButton cancelBtn = new JButton("取消");
        saveBtn.addActionListener(e -> onSave());
        cancelBtn.addActionListener(e -> dispose());
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadConfig() {
        urlField.setText(config.getProperty("api.url"));
        keyField.setText(config.getProperty("api.key"));
        modelComboBox.setSelectedItem(config.getProperty("api.model"));
        providerComboBox.setSelectedItem(config.getProperty("api.provider"));
    }

    private void onSave() {
        config.setProperty("api.url", urlField.getText().trim());
        config.setProperty("api.key", new String(keyField.getPassword()));
        config.setProperty("api.model", modelComboBox.getSelectedItem().toString().trim());
        config.setProperty("api.provider", providerComboBox.getSelectedItem().toString().trim());

        try {
            config.saveToFile();
            JOptionPane.showMessageDialog(this, "✅ 配置已保存！\n部分更改需重启应用生效。", "成功", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ 保存失败:\n" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}